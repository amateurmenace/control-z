# DaVinci Wide Gamut / Intermediate Middle-Gray PowerGrade

This package places a neutral control point on Resolve's ganged **Custom Curves** at the exact encoded position of 18% scene-linear middle gray in **DaVinci Intermediate**.

## Exact anchor

- Normalized input: **0.336043**
- Normalized output: **0.336043**
- Resolve internal 0–1023 curve coordinate: **343.771989**
- Approximate 10-bit code value when rounded for display: **344**

The point is on the identity diagonal, so applying the grade does not change the image. It acts as a fixed middle-gray pivot while you shape the curve above and below it.

## Import and use

1. On Resolve's **Color** page, open **Gallery > PowerGrade**.
2. Right-click an empty area, choose **Import**, and select `DWG_Intermediate_Middle_Gray_Anchor_v1.0.drx`.
3. Apply the PowerGrade to a clip or append its node to your node tree.
4. Use it only where the node receives **DaVinci Wide Gamut / DaVinci Intermediate** data.
5. Open **Curves > Custom**. The ganged YRGB curve contains the middle-gray anchor at input/output `0.336043`.
6. Leave that point on the diagonal while shaping contrast around it.

## Color-management requirement

The anchor belongs in the scene-referred working section of the grade. In Resolve Color Management, use a DaVinci Wide Gamut / Intermediate timeline or node working space. In a manual CST pipeline, place this node after the input transform to DWG/Intermediate and before the output transform.

Do not use the same coordinate in another gamma. The 18% gray code value depends on the transfer function.

## Compatibility

The included DRX was authored and round-trip tested in DaVinci Resolve 21.0.0 build 48. The grade uses only standard Custom Curves controls and no Studio-only effects.
